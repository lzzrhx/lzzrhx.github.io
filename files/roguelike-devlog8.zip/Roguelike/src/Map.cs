using Raylib_cs;
using System.Numerics;

namespace Roguelike;

/// <summary>
/// World map.
/// </summary>
public class Map
{
    // Map size
    public readonly int width;
    public readonly int height;

    // Map data
    public BspTree tree { get; private set; }
    private bool?[,] map;
    private List<int> mapSeen = new List<int>();
    private List<int> mapVisible = new List<int>();
    public readonly PathGraph pathGraph;
    private List<int> doors = new List<int>();

    // Lighting system
    private List<int> lights = new List<int>();
    private Dictionary<int, int> lightMap = new Dictionary<int, int>();
    private Dictionary<int, int> blocksLight = new Dictionary<int, int>();

    // Constructor
    public Map(int width, int height)
    {
        this.width = width;
        this.height = height;
        this.map = new bool?[width, height];
        this.pathGraph = new PathGraph(this);
        this.tree = new BspTree(this, width, height);
        BuildMap();
    }

    public int MapCoord(int x, int y)
    {
        return (width * y) + x;
    }

    // Converts mapcoord to Vec2
    public Vec2 MapCoordReverse(int coord)
    {
        return new Vec2(coord % width, coord / width);
    }

    // Returns true if a given Vec2 location is within the map bounds
    public bool InBounds(Vec2 location)
    {
        if (location.x >= 0 && location.x < width && location.y >= 0 && location.y < height) { return true; }
        return false;
    }

    // Returns true if a given Vec2 location blocks vision
    public bool GetVisionBlocking(Vec2 location)
    {
        return InBounds(location) ? map[location.x, location.y] == false : true;
    }

    // Clear the list of visible locations
    public void ClearVisible()
    {
        mapVisible.Clear();
    }

    // Set a given Vec2 location to visible   
    public void SetVisible(Vec2 location)
    {
        if (InBounds(location)) 
        { 
            int coord = MapCoord(location.x, location.y);
            mapSeen.Add(coord);
            mapVisible.Add(coord);
        }
    }

    // Returns true if a given location has been seen at some point
    public bool GetSeen(int coord)
    {
        return mapSeen.Contains(coord);
    }

    // Returns true if a given location is visible
    public bool GetVisible(int coord)
    {
        return mapVisible.Contains(coord);
    }

    // Return the light intensity for a given point on the map
    private int GetLightIntensity(int x, int y)
    {
        int coord = MapCoord(x, y);
        if (lightMap.ContainsKey(coord))
        {
            return lightMap[coord];
        }
        return 0;
    }

    // Build the map
    private void BuildMap() {

        // Build all rooms
        tree.VisitAllNodes(BuildRoom);

        // Build all corridors
        tree.VisitAllNodes(BuildCorridor);

        // Make lightmap
        lightMap = pathGraph.DijkstraMap(lights, blocksLight, 24);
    }

    // Add a lightsource to the map
    public void AddLight(int x, int y)
    {
        int coord = MapCoord(x, y);
        if (!lights.Contains(coord) && map[x, y] == true)
        { 
            lights.Add(coord);
        }
    }

    // Add a door to the map
    public void AddDoor(int x, int y)
    {
        int coord = MapCoord(x, y);
        if (map[x, y] == true)
        { 
            doors.Add(coord);
            blocksLight[coord] = 12;
        }
    }

    // Returns true if a given location contains a door
    public bool GetDoor(int coord)
    {
        return doors.Contains(coord);
    }

    // Build room from a node
    private void BuildRoom(BspNode node)
    {
        if (node.HasRoom())
        {
            Room room = node.room;
            BuildSpace(room.x, room.y, room.width, room.height, room.area);

            // Add lights
            foreach (Vec2 light in room.lights)
            {
                AddLight(room.x + light.x, room.y + light.y);
            }
        }
    }

    // Build corridor from a node
    private void BuildCorridor(BspNode node)
    {
        // Build corridor
        if (node.HasCorridor())
        {
            Corridor corridor = node.corridor;
            BuildSpace(corridor.x, corridor.y, corridor.width, corridor.height, corridor.area);
            
            // Add doors
            foreach (Vec2 door in corridor.doors)
            {
                AddDoor(corridor.x + door.x, corridor.y + door.y);
            }
        }
    }

    // Transfer location to world space and carve out area
    private void BuildSpace(int worldX, int worldY, int width, int height, bool?[,] area)
    {
        for (int y = 0; y < height; y++)
        {
            for (int x = 0; x < width; x++)
            {
                if (area[x, y] != null){ map[worldX + x, worldY + y] = area[x, y]; }
            }
        }
    }

    // Render map
    public void Render3D()
    {
        for (int y = 0; y < height; y++)
        {
            for (int x = 0; x < width; x++)
            {
                if (map[x, y] != null)
                {
                    // Get the coord for the current location
                    int coord = MapCoord(x, y);

                    // Check if location has been seen
                    if (GetSeen(coord) || Game.debugMode)
                    {
                        Color color = Color.LightGray;

                        // Check if location is visible
                        if (GetVisible(coord)) {

                            // Check if the current location is open space
                            if (map[x, y] == true) {

                                // Set floor color
                                color = Color.Green;

                                // Visualize light intensity
                                int lightIntensity = GetLightIntensity(x, y);
                                Color lightColor = Color.Gray;
                                if (lightIntensity > 16) { lightColor = Color.Yellow; }
                                else if (lightIntensity > 8) { lightColor = new Color(200, 200, 0, 255);; }
                                else if (lightIntensity > 0) { lightColor = new Color(150, 150, 0, 255);; }

                                Raylib.DrawSphereEx(new Vector3(x + 0.5f, 0.5f, y + 0.5f), 0.15f, 4, 4, lightColor);

                                // Check if the current location contains a door
                                if (GetDoor(coord))
                                {
                                    // Set door color
                                    color = Color.Blue;
                                }
                            }

                            // If not then the current location is a wall
                            else 
                            {
                                // Set wall color
                                color = Color.Red;
                            }
                        }

                        // Draw floor
                        Raylib.DrawCubeWiresV(new Vector3(x + 0.5f, -0.5f, y + 0.5f), new Vector3(1.0f, 1.0f, 1.0f), color);

                        // Draw wall
                        if (map[x, y] == false) {
                            Raylib.DrawCubeWiresV(new Vector3(x + 0.5f, 0.5f, y + 0.5f), new Vector3(1.0f, 1.0f, 1.0f), color);
                        }

                        // Draw player indicator
                        if (Game.player.x == x && Game.player.y == y)
                        {
                            Raylib.DrawPlane(new Vector3(x + 0.5f, 0.0f, y + 0.5f), new Vector2(1.0f, 1.0f), Color.Yellow);
                        }

                        // Draw door indicator
                        else if (GetDoor(coord))
                        {
                            Raylib.DrawPlane(new Vector3(x + 0.5f, 0.0f, y + 0.5f), new Vector2(1.0f, 1.0f), color);
                        }

                    }
                }
            }
        }
    }

    // Render minimap
    public void Render2D()
    {
        int cellSize = 6;
        int xOffset = Raylib.GetRenderWidth() - (width * cellSize);
        Raylib.DrawRectangle(xOffset, 0, width * cellSize, height * cellSize, Color.DarkGray);
        for (int y = 0; y < height; y++)
        {
            for (int x = 0; x < width; x++)
            {
                if (map[x, y] != null)
                {

                    // Show player position on minimap
                    if (Game.player.x == x && Game.player.y == y)
                    {
                        Raylib.DrawRectangle(xOffset + (x * cellSize), y * cellSize, cellSize, cellSize, Color.Yellow);
                    }

                    else
                    {
                        // Get the coord for the current location
                        int coord = MapCoord(x, y);

                        // Check if location has been seen
                        if (GetSeen(coord) || Game.debugMode)
                        {
                            Color color = Color.LightGray;

                            // Check if location is visible
                            if (GetVisible(coord)) {
                                
                                // Check if location is open space
                                if (map[x, y] == true) {
                                    
                                    // Set floor color
                                    color = Color.Green;

                                    // Check if the current location contains a door
                                    if (GetDoor(coord))
                                    {
                                        // Set door color
                                        color = Color.Blue;
                                    }
                                }

                                // If not then the current location is a wall
                                else 
                                {
                                    // Set wall color
                                    color = Color.Red;
                                }
                            }

                            // Draw minimap cell
                            Raylib.DrawRectangleLines(xOffset + (x * cellSize), y * cellSize, cellSize, cellSize, color);
                        }
                    }
                }
            }
        }
    }
}
