﻿using Raylib_cs;
using rlImGui_cs;
using ImGuiNET;
using System.Numerics;

namespace Roguelike;

static class Game
{
    private static bool isRunning = true;
    public static bool debugMode { get; private set; } = false;
    public static Map map { get; private set; }
    public static Player player { get; private set; }
    public static Planet planet { get; private set; }
    private static Camera3D camera;

    // Program entry point
    static void Main(string[] args)
    {
        Init();
        Run();
        Exit();
    }

    // Initialize
    private static void Init()
    {
        // Raylib & Imgui initialization
        Raylib.InitWindow(1280, 720, "Roguelike");
        Raylib.SetTargetFPS(30);
        rlImGui.Setup(true);

        // Create new objects
        //map = new Map(96, 48);
        //player = new Player();
        planet = new Planet(10);
        
        // Camera setup
        camera.Position = Vector3.Zero;
        camera.Target = Vector3.Zero;
        camera.Up = Vector3.UnitY;
        camera.FovY = 45.0f;
        camera.Projection = CameraProjection.Perspective;
    }

    // Main game loop
    private static void Run()
    {
        while (!Raylib.WindowShouldClose())
        {
            Input();
            Update();
            Render();
        }
    }

    // Exit game
    private static void Exit()
    {
        planet.Exit();
        rlImGui.Shutdown();
        Raylib.CloseWindow();
    }

    // Handle user input
    private static void Input()
    {
        // System
        if (Raylib.IsKeyPressed(KeyboardKey.Tab)) { debugMode = !debugMode; }
        if (Raylib.IsKeyPressed(KeyboardKey.F)) { Raylib.ToggleFullscreen(); }
        
        // Player movement
        //if (Raylib.IsKeyPressed(KeyboardKey.Up)) { player.MoveUp(); }
        //else if (Raylib.IsKeyPressed(KeyboardKey.Down)) { player.MoveDown(); }
        //else if (Raylib.IsKeyPressed(KeyboardKey.Left)) { player.MoveLeft(); }
        //else if (Raylib.IsKeyPressed(KeyboardKey.Right)) { player.MoveRight(); }
    }

    // Update things in the game
    private static void Update()
    {
        float deltaTime = Raylib.GetFrameTime();

        planet.Update(deltaTime);

        // Camera
        //Vector3 cameraTargetGoal = new Vector3((float)player.x, 0f, (float)player.y);
        Vector3 cameraTargetGoal = planet.pos;
        camera.Target = Raymath.Vector3Distance(camera.Target, cameraTargetGoal) > 0.1f ? Raymath.Vector3Lerp(camera.Target, cameraTargetGoal, 0.05f) : camera.Target;
        camera.Position = camera.Target + new Vector3(0f, 18.0f, 18.0f);
    }

    // Render things on screen
    private static void Render()
    {
        // Start render
        Raylib.BeginDrawing();

        // Set background color
        Raylib.ClearBackground(Color.Black);

        // 3D rendering
        Raylib.BeginMode3D(camera);
        if (debugMode) { Raylib.DrawGrid(300, 1.0f); }
        //map.Render3D();
        //player.Render3D();
        planet.Render3D();
        Raylib.EndMode3D();

        // 2D rendering
        //map.Render2D();
        planet.Render2D();
        Raylib.DrawFPS(2,2);
        //Raylib.DrawText("POSITION: " + player.x.ToString() + "x" + player.y.ToString(), 2, Raylib.GetRenderHeight() - 16, 16, Color.White);
        
        // 2D rendering (debug mode)
        if (debugMode) {
            Raylib.DrawText("DEBUG MODE", 2, 20, 16, Color.White);
            RenderImGui();
        }

        // End render
        Raylib.EndDrawing();
    }

    // Render ImGui
    private static void RenderImGui()
    {
        // Start ImGui
        rlImGui.Begin();

        //ImGui.ShowDemoWindow();
        
        // Debug window
        if (ImGui.Begin("Debug window"))
        {
            ImGui.Text("Log:");
            ImGui.BeginChild("Log");
            for (int i = 0; i < Logger.log.Count; i++)
            {
                LogEntry logEntry = Logger.log[i];
                ImGui.Text(logEntry.message);
            }
            ImGui.EndChild();
        }

        // End ImGui
        ImGui.End();
        rlImGui.End();
    }
}