﻿class Program
{
    static void Main(string[] args)
    {
        uint seed = (uint)10;
        Console.WriteLine("(32-bit) seed: " + Convert.ToString(seed, 2).PadLeft(32, '0'));
        Lfsr.Check32(ref seed);
        Lfsr.Check32(ref seed);
        Lfsr.Check32(ref seed);
        Lfsr.Make32(ref seed);
    }
}
