﻿using System.Numerics;
using Raylib_cs;

static class Program
{
    private static Texture2D textureCA;
    private static Texture2D textureDLA;
    private static Texture2D textureDW;
    private static Texture2D textureV;
    private static uint seed = (uint)1337;

    static void Main(string[] args)
    {
        Init();
        Run();
        Exit();
    }
    
    private static void Init()
    {
        Raylib.InitWindow(2400, 600, "mapgen algorithms demo");
        Raylib.SetTargetFPS(30);
        Lfsr.Shift32(ref seed);
        MakeTexBool(CellularAutomata.Run(ref seed, 200, 200), out textureCA);
        MakeTexBool(DiffusionLimitedAggregation.Run(ref seed, 200, 200), out textureDLA);
        MakeTexBool(DrunkardsWalk.Run(ref seed, 200, 200), out textureDW);
        MakeTexInt(Voronoi.Run(ref seed, 200, 200, numSeeds: 20), maxNum: 20, out textureV);
    }
    
    private static void Run()
    {
        while (!Raylib.WindowShouldClose())
        {
            Render();
        }
    }

    private static void Exit()
    {
        Raylib.UnloadTexture(textureCA);
        Raylib.UnloadTexture(textureDLA);
        Raylib.UnloadTexture(textureDW);
        Raylib.UnloadTexture(textureV);
        Raylib.CloseWindow();
    }

    private static void Render()
    {
        Raylib.BeginDrawing();
        Raylib.ClearBackground(Color.Black);
        Raylib.DrawTextureEx(textureCA, new Vector2(0f, 24f), 0f, 3f, Color.White);
        Raylib.DrawTextureEx(textureDLA, new Vector2(600f, 24f), 0f, 3f, Color.White);
        Raylib.DrawTextureEx(textureDW, new Vector2(1200f, 24f), 0f, 3f, Color.White);
        Raylib.DrawTextureEx(textureV, new Vector2(1800f, 24f), 0f, 3f, Color.White);
        Raylib.DrawText("CELLULAR AUTOMATA:", 8, 2, 20, Color.White); 
        Raylib.DrawText("DIFFUSION LIMITED AGGREGATION:", 608, 2, 20, Color.White); 
        Raylib.DrawText("DRUNKARD'S WALK:", 1208, 2, 20, Color.White); 
        Raylib.DrawText("VORONOI:", 1808, 2, 20, Color.White); 
        Raylib.EndDrawing();
    }

    private static unsafe void MakeTexBool(bool[,] map, out Texture2D result)
    {
        byte* pixels = (byte*)Raylib.MemAlloc((uint)((map.GetLength(0) * map.GetLength(1)) * sizeof(byte)));
        for (int y = 0; y < map.GetLength(0); y++)
        {
            for (int x = 0; x < map.GetLength(1); x++) 
            {
                pixels[y * map.GetLength(0) + x] = (byte)(map[y,x] ? 255 : 0);
            }
        }
        Image img = new Image
        {
            Data = pixels,
            Width = map.GetLength(1),
            Height = map.GetLength(0),
            Format = PixelFormat.UncompressedGrayscale,
            Mipmaps = 1,
        };
        result = Raylib.LoadTextureFromImage(img);
        Raylib.UnloadImage(img);
    }


    private static unsafe void MakeTexInt(int[,] map, int maxNum, out Texture2D result)
    {
        byte* pixels = (byte*)Raylib.MemAlloc((uint)((map.GetLength(0) * map.GetLength(1)) * sizeof(byte)));
        for (int y = 0; y < map.GetLength(0); y++)
        {
            for (int x = 0; x < map.GetLength(1); x++) 
            {
                pixels[y * map.GetLength(0) + x] = (byte)((float)map[y,x] * (float)(255f / (float)maxNum));
            }
        }
        Image img = new Image
        {
            Data = pixels,
            Width = map.GetLength(1),
            Height = map.GetLength(0),
            Format = PixelFormat.UncompressedGrayscale,
            Mipmaps = 1,
        };
        result = Raylib.LoadTextureFromImage(img);
        Raylib.UnloadImage(img);
    }

}
