﻿namespace Roguelike;

static class Game
{
    static void Main(string[] args)
    {
        Map map = new Map(96, 48);
    }
}
