using Raylib_cs;
using System.Numerics;

namespace Roguelike;

/// <summary>
/// Player controlled character.
/// </summary>
public class Player
{
    public int x { get; private set; }
    public int y { get; private set; }
    private int visionRange = 48;

    public Player()
    {
        Spawn();
        Fov();
    }

    private void Spawn()
    {
        Room room = Game.map.tree.FindLeftLeaf(Game.map.tree.root).room;
        this.x = room.x + 1;
        this.y = room.y + 1;
    }

    public void Render3D()
    {
        Raylib.DrawSphereWires(new Vector3((float)x + 0.5f, 0.5f, (float)y + 0.5f), 0.5f, 4, 4, Color.Pink);
    }

    private void Fov()
    {
        Game.map.ClearVisible();
        Shadowcast.Run(Game.map, new Vec2(x, y));
    }

    public bool MoveUp()
    {
        if (Game.map.pathGraph.HasLocation(Game.map.MapCoord(x, y-1))) { y--; Fov(); return true; }
        return false;
    }

    public bool MoveDown()
    {
        if (Game.map.pathGraph.HasLocation(Game.map.MapCoord(x, y+1))) { y++; Fov(); return true; }
        return false;
    }
    
    public bool MoveLeft()
    {
        if (Game.map.pathGraph.HasLocation(Game.map.MapCoord(x-1, y))) { x--; Fov(); return true; }
        return false;
    }
    
    public bool MoveRight()
    {
        if (Game.map.pathGraph.HasLocation(Game.map.MapCoord(x+1, y))) { x++; Fov(); return true; }
        return false;
    }
}
