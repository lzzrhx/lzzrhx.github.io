﻿using System.Numerics;
using Raylib_cs;

static class Program
{
    private static Texture2D texture;

    static void Main(string[] args)
    {
        Init();
        Run();
        Exit();
    }
    
    private static void Init()
    {
        Raylib.InitWindow(1000, 1000, "noise demo");
        Raylib.SetTargetFPS(30);
        MakeTex(1000, 1000, out texture);
    }
    
    private static void Run()
    {
        while (!Raylib.WindowShouldClose())
        {
            Render();
        }
    }

    private static void Exit()
    {
        Raylib.UnloadTexture(texture);
        Raylib.CloseWindow();
    }

    private static void Render()
    {
        Raylib.BeginDrawing();
        Raylib.ClearBackground(Color.Black);
        Raylib.DrawTexture(texture, 0, 0, Color.White);
        Raylib.EndDrawing();
    }

    private static unsafe void MakeTex(int width, int height, out Texture2D result)
    {
        float seed = 0f;
        byte* pixels = (byte*)Raylib.MemAlloc((uint)((height * width) * sizeof(byte)));
        for (int y = 0; y < height; y++)
        {
            for (int x = 0; x < width; x++) 
            {
                Vector2 pos = new Vector2((float)x, (float)y);
                float noise = Perlin.Noise3(pos * 0.15f, seed);
                pixels[y * height + x] = (byte)(noise * 255f);
            }
        }
        Image img = new Image
        {
            Data = pixels,
            Width = width,
            Height = height,
            Format = PixelFormat.UncompressedGrayscale,
            Mipmaps = 1,
        };
        result = Raylib.LoadTextureFromImage(img);
        Raylib.UnloadImage(img);
    }

}
