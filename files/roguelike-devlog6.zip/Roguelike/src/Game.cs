﻿namespace Roguelike;

static class Game
{
    private static bool isRunning = true;
    public static Map map { get; private set; }
    public static Player player { get; private set; }

    // Program entry point
    static void Main(string[] args)
    {
        Init();
        Run();
        Exit();
    }

    // Initialize
    private static void Init()
    {
        map = new Map(96, 48);
        player = new Player();
    }

    // Main game loop
    private static void Run()
    {
        // Setup console
        Console.CursorVisible = false;
        Console.ResetColor();
        Console.Clear();

        while (isRunning)
        {
            Render();
            Input();
        }

        // Reset console back to normal
        Console.CursorVisible = true;
        Console.ResetColor();
        Console.Clear();
    }

    // Exit game
    private static void Exit()
    {
        Console.WriteLine("Quitting..");
    }

    // Handle user input
    private static void Input()
    {
        // Loop until valid input is given
        bool validKey = false;
        while (!validKey)
        {
            // Wait for and get key input from user
            ConsoleKeyInfo key = Console.ReadKey(true);

            // Check if key was valid and process input
            validKey = ProcessInput(key);
        }
    }

    // Check if the pressed key was valid and process input
    private static bool ProcessInput(ConsoleKeyInfo key)
    {
            switch (key.Key)
            {
                case ConsoleKey.UpArrow:
                    return player.MoveUp();
                case ConsoleKey.DownArrow:
                    return player.MoveDown();
                case ConsoleKey.LeftArrow:
                    return player.MoveLeft();
                case ConsoleKey.RightArrow:
                    return player.MoveRight();
                case ConsoleKey.Escape:
                    isRunning = false;
                    return true;
            }

            return false;
    }

    // Render things on screen
    private static void Render()
    {
        // NOTE: This is a very inefficient way to clear the console that will result in heavy flickering, but it's just a temporary sollution.
        Console.Clear();
        map.Render();
    }
}
